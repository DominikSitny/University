package com.example.demo;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entity.Adresse;
import com.example.demo.entity.Student;
import com.example.demo.repo.StudentRepository;

@SpringBootTest
class DatabaseApplicationTests {

	@Autowired
	StudentRepository repository;
	
	@Test
	void contextLoads() {
		
	}
	
	@Test
	void insertOfStudent() {
		Student student = new Student("Markus", "Müller");

    	Adresse adress1 = new Adresse();
    	adress1.setStrasseHNr("Hauptstrasse 4");
    	adress1.setPLZOrt("33619 Bielefeld");

    	student.setAdresse(adress1);
    	adress1.setStudent(student);
    	student = repository.save(student);

    	Optional<Student> s1 = repository.findById(student.getId());
    	assertThat(s1.get().getNachname()).isEqualTo(student.getNachname());
	}

}
