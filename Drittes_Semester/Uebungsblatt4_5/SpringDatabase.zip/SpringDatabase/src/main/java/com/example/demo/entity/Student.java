package com.example.demo.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;



/**
 * Student class.
 * 
 */


@Entity
public class Student {
	
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Id
	private int id;
	
	private String vorname;
	private String nachname;
	
	@OneToOne(cascade=CascadeType.PERSIST)
	@JoinColumn(name = "adresse")
	private Adresse adresse;
	
	public Student()
	{
		super();
	
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Student(String f, String l)
	{
		vorname = f;
		nachname = l;
	}
	
	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getNachname() {
		return nachname;
	}

	public void setNachname(String nachname) {
		this.nachname = nachname;
	}

	public Adresse getAdresse() {
		return adresse;
	}

	public void setAdresse(Adresse adresse) {
		this.adresse = adresse;
	}

	public String getData() {
		
		return "Student: " + this.getVorname() + " " + this.getNachname();
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", vorname=" + vorname + ", nachname=" + nachname + "]";
	}
	
}
